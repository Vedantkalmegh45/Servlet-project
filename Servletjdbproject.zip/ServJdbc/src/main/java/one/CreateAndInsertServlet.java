package one;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/CreateAndInsertServlet")
public class CreateAndInsertServlet extends HttpServlet {
     String DB_URL = "jdbc:mysql://Localhost:3306/demoserv1";
     String USER = "root";
     String PASS = "1234";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        Connection conn = null;
        Statement stmt = null;

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish the connection
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement();

            // SQL command to create a table
            String createTableSQL = "CREATE TABLE  Users " +
                    "(id INT  AUTO_INCREMENT PRIMARY KEY , " +
                    " name VARCHAR(255), " + 
                    " email VARCHAR(255))";
            stmt.executeUpdate(createTableSQL);

            // SQL command to insert values
            String insertSQL = "INSERT INTO Users (name, email) VALUES " +
                    "('Alice', 'alice@example.com'), " +
                    "('Bob', 'bob@example.com')";
            stmt.executeUpdate(insertSQL);

            out.println("Table created and values inserted successfully!");
        } catch (SQLException se) {
            se.printStackTrace();
            out.println("SQL Error: " + se.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        } 
        }
    }

