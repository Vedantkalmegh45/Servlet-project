package one;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/JDBCServ")
public class JDBCServ extends HttpServlet {
	
	String DB_Url="jdbc:mysql://Localhost:3306/demo45";
	String USER="root";
	String PASS="1234";
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		Connection con=null;
		Statement stmt=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
		 con=DriverManager.getConnection(DB_Url,USER,PASS);
			stmt=con.createStatement();
			//-------------------------------------------------------
			//sql command to create table
			String createTable="CREATE TABLE Users"+
			"(id INT AUTO_INCREMENT PRIMARY KEY, "+
			"name VARCHAR(255) ,"+
			"email VARCHAR(255))";
			
			stmt.executeUpdate(createTable);
			//----------------------------------------------------------
			//sql command to insert values
			String insertvalues="INSERT INTO Users(id,name,email) VALUES"+
			"('101','deepak','deepak@gmail.com'),"+
					"('102','akash','akash@gamil.com')";
			
			stmt.executeUpdate(insertvalues);
			//---------------------------------------------------
			out.print("Table created and values inserted successfully");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}